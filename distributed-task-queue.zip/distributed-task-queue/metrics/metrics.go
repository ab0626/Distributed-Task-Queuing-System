package metrics

import (
    "github.com/prometheus/client_golang/prometheus"
    "github.com/prometheus/client_golang/prometheus/promhttp"
    "net/http"
)

var (
    TasksSubmitted = prometheus.NewCounter(
        prometheus.CounterOpts{
            Name: "tasks_submitted_total",
            Help: "Total number of tasks submitted via API",
        },
    )
)

func Init() {
    prometheus.MustRegister(TasksSubmitted)
    http.Handle("/metrics", promhttp.Handler())
    go http.ListenAndServe(":9100", nil)
}
