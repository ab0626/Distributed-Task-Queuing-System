package main

import (
    "github.com/gin-gonic/gin"
    "task-queue-system/api"
    "task-queue-system/metrics"
)

func main() {
    metrics.Init()

    r := gin.Default()
    r.POST("/submit", api.SubmitTaskHandler)
    r.GET("/health", func(c *gin.Context) {
        c.JSON(200, gin.H{"status": "OK"})
    })
    r.Run(":8080")
}
