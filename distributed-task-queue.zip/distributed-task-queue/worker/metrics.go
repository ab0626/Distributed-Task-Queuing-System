package main

import (
    "net/http"
    "github.com/prometheus/client_golang/prometheus"
    "github.com/prometheus/client_golang/prometheus/promhttp"
)

var (
    TasksProcessed = prometheus.NewCounter(prometheus.CounterOpts{
        Name: "tasks_processed_total",
        Help: "Number of tasks processed",
    })

    TasksFailed = prometheus.NewCounter(prometheus.CounterOpts{
        Name: "tasks_failed_total",
        Help: "Number of tasks that failed processing",
    })

    TasksRetried = prometheus.NewCounter(prometheus.CounterOpts{
        Name: "tasks_retried_total",
        Help: "Number of task retries",
    })
)

func initMetrics() {
    prometheus.MustRegister(TasksProcessed, TasksFailed, TasksRetried)
    go http.ListenAndServe(":9101", promhttp.Handler())
}
